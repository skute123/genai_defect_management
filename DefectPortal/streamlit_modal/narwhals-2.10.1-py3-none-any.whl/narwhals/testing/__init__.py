from __future__ import annotations

from narwhals.testing.asserts.series import assert_series_equal

__all__ = ("assert_series_equal",)
